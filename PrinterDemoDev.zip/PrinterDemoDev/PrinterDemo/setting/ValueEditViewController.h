//
//  ValueEditViewController.h
//  PrinterDemo
//
//  Created by doulai on 10/1/15.
//  Copyright © 2015 com.cmcc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ValueEditViewController : UIViewController
@property (nonatomic,strong) NSString *keyword;
@end
